from pybrain.rl.environments.flexcube.environment import FlexCubeEnvironment
from pybrain.rl.environments.flexcube.tasks import *
