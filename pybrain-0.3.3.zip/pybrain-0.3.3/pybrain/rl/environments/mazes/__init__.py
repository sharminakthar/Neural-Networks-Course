from pybrain.rl.environments.mazes.maze import Maze
from pybrain.rl.environments.mazes.polarmaze import PolarMaze
from pybrain.rl.environments.mazes.tasks.__init__ import *