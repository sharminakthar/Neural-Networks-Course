from pybrain.rl.environments.simple.environment import SimpleEnvironment
from pybrain.rl.environments.simple.tasks import MinimizeTask